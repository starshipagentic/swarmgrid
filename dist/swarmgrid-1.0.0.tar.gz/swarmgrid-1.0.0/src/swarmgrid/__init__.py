"""Local Jira heartbeat package."""
